-- Table definitions for the tournament project.
--
-- Put your SQL 'create table' statements in this file; also 'create view'
-- statements if you choose to use it.
--
-- You can write comments in this file by starting them with two dashes, like
-- these lines here.

-- Delete previous database if exists
DROP DATABASE IF EXISTS tournament;

CREATE DATABASE tournament;

-- connect to the newly created one
\c tournament;

-- Creating the tables

-- Creating the table for the players id, names
create table players (
    id serial primary key,
    name text
);

-- Creating the table for tournaments id, tour_names
create table tours (
    id serial primary key,
    name text
);

-- Registring the players associated with each tour
create table tour_registry(
    id int references players(id),
    tour int references tours(id),
    primary key (id, tour)
);

-- Creating match table with match id, tour name
create table matches(
    id serial primary key,
    tour int references tours(id)
);

-- Type used in players results
create type match_result as enum ('win', 'loss', 'draw');

-- 	Creating table that shows whether player won, lost or draw

create table player_results (
    player int references players(id),
    match int references matches(id),
    result match_result
);

/***************/
/*****Views*****/
/***************/

-- Creating views that shows no of players enrolled for each tournament
create view tour_enrollment as 
	select tours.id, tours.name as tourName, 
	count(tour_registry.player) as num
	from tour_registry, tours
	where tours.id = tour_registry.tour
	group by tours.id;

-- Creating view that returns the player_results and tour column
create view player_results_with_tour as 
	select player, matches.tour, player_results.match, result 
	from player_results, matches
	where player_results.match = matches.id;

-- Creating view that will show the number of wins by each player in each tour
create view player_wins as 
	select tour_registry.player, tour_registry.tour, 
	count(result) as wins
	from tour_registry left join player_results_with_tour 
	on tour_registry.player = 
	player_results_with_tour.player
	and tour_registry.tour = 
	player_results_with_tour.tour
	and result = 'win'
	group by tour_registry.player, tour_registry.tour
	order by tour_registry.tour, tour_registry.player;

-- Creating view that will show the number of losses by each player in each tour
create view player_losses as 
	select tour_registry.player, tour_registry.tour, 
	count(result) as losses
	from tour_registry left join player_results_with_tour 
	on tour_registry.player = 
	player_results_with_tour.player
	and tour_registry.tour = 
	player_results_with_tour.tour
	and result = 'loss'
	group by tour_registry.player, tour_registry.tour
	order by tour_registry.tour, tour_registry.player;

-- Creating view that will show the number of draws by each player in each tour
create view player_draws as 
	select tour_registry.player, tour_registry.tour, 
	count(result) as draws
	from tour_registry left join player_results_with_tour 
	on tour_registry.player = 
	player_results_with_tour.player
	and tour_registry.tour = 
	player_results_with_tour.tour
	and result = 'draw'
	group by tour_registry.player, tour_registry.tour
	order by tour_registry.tour, tour_registry.player;		 

-- Creating view that will show the number of wins, losses and draws by each player in each tour
create view standings as 
	select player_wins.player, player_wins.tour, wins, losses,  
	draws, wins + losses + draws as played
	from player_wins join player_losses 
	on player_wins.player = player_losses.player and
	player_wins.tour = player_losses.tour
	join player_draws
	on player_wins.player = player_losses.player and
	player_wins.tour = player_draws.tour;