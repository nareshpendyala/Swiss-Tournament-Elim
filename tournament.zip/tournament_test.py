#!/usr/bin/env python
#
# Test cases for tournament.py
# These tests are not exhaustive, but they should cover the majority of cases.
#
# If you do add any of the extra credit options, be sure to add/modify these test cases
# as appropriate to account for your module's added functionality.

from tournament import *


#register players
names = ['Naresh', 'Anu', 'Swathi', 'Dhana', 'Sai', 'Bhagi']
nameIDs = []

for name in names:
    nameIDs.append((registerPlayer(name), name))

#nameIDs
#[(1, 'Naresh'), (2, 'Anu'), (3, 'Swathi'), (4, 'Dhana'), (5, 'Sai'), (6, 'Bhagi')]

# register tour events
events = ['Chess', 'Football', 'Cricket', 'Vollyball']
eventIDs = []

for event in events:
    eventIDs.append((registerTour(event), event))


# eventIDS
# [(1, 'Chess'), (2, 'Football'), (3, 'Cricket'), (4, 'Vollyball')]

#register all names for all the tours
for event in eventIDs:
    for name in nameIDs:
        enrollPlayerInTour(name[0], event[0])

# test countPlayers(tour_id)
for event in eventIDs:
    if countPlayers(event[0]) !=len(names):
        raise ValueError("countPlayers(" + tour_id + ") incorrectly returned " + countPlayers(event[0]))

#test reportMatch

# ROUND 1
#Naresh draws with Anu
reportMatch(eventIDs[0][0], nameIDs[0][0], nameIDs[1][0], draw = True)
#Swathi beats Dhana
reportMatch(eventIDs[0][0], nameIDs[2][0], nameIDs[3][0])
#Sai beats Bhagi
reportMatch(eventIDs[0][0], nameIDs[4][0], nameIDs[5][0])

# ROUND 2
#Swathi beats Sai
reportMatch(eventIDs[0][0], nameIDs[2][0], nameIDs[4][0])
#Naresh beats Dhana
reportMatch(eventIDs[0][0], nameIDs[0][0], nameIDs[3][0])
#Anu beats Bhagi
reportMatch(eventIDs[0][0], nameIDs[1][0], nameIDs[5][0])  


# Checkpoint check Swiss Pairings
expectedPairings = [nameIDs[2] + nameIDs[0] , nameIDs[1] + nameIDs[4] , nameIDs[3] + nameIDs[5]]
actualPairings = swissPairings(eventIDs[0][0])

for i in range(len(expectedPairings)):
    if expectedPairings[i][0] != actualPairings[i][0] and expectedPairings[i][0] != actualPairings[i][2]:
        raise ValueError('returned swissPairings do not match')
    if expectedPairings[i][2] != actualPairings[i][0] and expectedPairings[i][2] != actualPairings[i][2]:
        raise ValueError('returned swissPairings do not match')
print 'swissPairings passed tests'


#ROUND 3
#Naresh draws with Swathi
reportMatch(eventIDs[0][0], nameIDs[2][0], nameIDs[0][0], draw = True)
#Anu beats Sai
reportMatch(eventIDs[0][0], nameIDs[1][0], nameIDs[4][0])
#Dhana beats Bhagi
reportMatch(eventIDs[0][0], nameIDs[3][0], nameIDs[5][0])
        

# ROUND 4
#Swathi beats Anu
reportMatch(eventIDs[0][0], nameIDs[2][0], nameIDs[1][0])
#Naresh beats Bhagi
reportMatch(eventIDs[0][0], nameIDs[0][0], nameIDs[5][0])
#Dhana beats Sai
reportMatch(eventIDs[0][0], nameIDs[3][0], nameIDs[4][0])

# Checkpoint check Swiss Pairings
expectedStandings = [(nameIDs[2][0], 3.5), (nameIDs[0][0], 3.0), (nameIDs[1][0], 2.5),
                 (nameIDs[3][0], 2.0), (nameIDs[4][0], 1.0), (nameIDs[5][0], 0.0)]
standings = playerStandings(eventIDs[0][0])

for i in range(len(expectedStandings)):
    if expectedStandings[i][0] != standings[i][0] or expectedStandings[i][1] != standings[i][6]:
        raise ValueError('returned standings do not match')
print 'playerStandings passed tests'
    
